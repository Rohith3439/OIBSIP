# oibsip_task5
Oasis Infobyte Internship (Java Development)

![IMG_20230913_202343](https://github.com/SoumyadipPal26/oibsip_task5/assets/128726200/48d80f3d-3879-4eec-b680-ad771b61d6aa)
